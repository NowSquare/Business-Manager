<?php

return [
    'name' => 'LeadPopups',
    'category' => 'marketing',
    'route_prefix' => 'popups',
    'role_or_permission' => 'Admin|Manager',
    'header_menu_name' => __("leadpopups::g.lead_popups"),
    'header_menu_icon' => 'comment',
];