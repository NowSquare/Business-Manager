
/**
 * First we will load all of this project's JavaScript dependencies which
 * includes Bootstrap and other libraries.
 */

require('./bootstrap');