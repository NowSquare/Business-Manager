<?php

return [
    'name' => 'Coupons',
    'category' => 'marketing',
    'route_prefix' => 'coupons',
    'role_or_permission' => 'Admin|Manager',
    'header_menu_name' => __("coupons::g.coupons"),
    'header_menu_icon' => 'redeem',
];