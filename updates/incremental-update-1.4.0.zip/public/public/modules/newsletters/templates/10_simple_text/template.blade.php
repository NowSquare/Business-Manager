<div style="background-color: #efefef">
  <div class="container" style="background-color: #fff">
    <table>
      <tbody>
        <tr>
          <td>
            <h1 class="heading">Insert title here</h1>
            <p class="paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque enim ligula, interdum sed egestas id, viverra sit amet nisi. Morbi a hendrerit sem. Donec et arcu augue. Cras feugiat tincidunt erat, a hendrerit tellus ultrices venenatis. Nam mattis elit leo, eu vestibulum dui ultricies a. Integer at lacus justo.</p>
            <p class="paragraph">Suspendisse at convallis ipsum. Vestibulum maximus enim felis, eget eleifend sem fermentum bibendum. Curabitur vel consequat risus. Sed vehicula ullamcorper arcu eu vulputate. Morbi id felis tristique, convallis est eu, tincidunt augue. Praesent congue justo ut dictum pretium. Curabitur sit amet nunc in lacus fermentum fermentum non eget nisi.</p>
            <p class="paragraph">In vitae nisl quis neque condimentum scelerisque non in leo. Sed vitae leo sollicitudin, fermentum mi congue, ultrices diam. Phasellus suscipit quam et mi sollicitudin lacinia.</p>
            <p class="paragraph">Maecenas elementum sapien in dictum pulvinar. Aliquam iaculis dui massa, eget pellentesque augue faucibus nec. Duis nec ipsum hendrerit neque scelerisque elementum et sit amet dui. Aenean congue semper nibh sed condimentum. Nunc non pulvinar ante, et venenatis magna. Proin eget fermentum ante.</p>
          </td>
        </tr>
      </tbody>
    </table>
    <table>
      <tbody>
        <tr>
          <td style="text-align: center">
            <a class="button" style="font-size: 18px; margin: 1rem 0">Call to Action</a>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>