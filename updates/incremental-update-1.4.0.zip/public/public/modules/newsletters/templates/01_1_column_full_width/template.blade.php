  <table>
    <tbody>
      <tr>
        <td>
          <div class="sub-container">
            <img src="{{ url('modules/newsletters/assets/img/logo.png') }}" style="margin:3rem auto"/>
          </div>
        </td>
      </tr>
    </tbody>
  </table>
  <table style="background-color: #f4f4f4">
    <tbody>
      <tr>
        <td>
          <div class="sub-container">
            <h1 class="heading">Insert title here</h1>
            <p class="paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque enim ligula, interdum sed egestas id, viverra sit amet nisi. Morbi a hendrerit sem. Donec et arcu augue.</p>
          </div>
        </td>
      </tr>
    </tbody>
  </table>
  <table>
    <tbody>
      <tr>
        <td>
          <div class="sub-container">
            <img src="{{ url('modules/newsletters/assets/img/image.png') }}"/>
          </div>
        </td>
      </tr>
    </tbody>
  </table>
  <table>
    <tbody>
      <tr>
        <td>
          <div class="sub-container">
            <h1 class="heading">Insert title here</h1>
            <p class="paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque enim ligula, interdum sed egestas id, viverra sit amet nisi. Morbi a hendrerit sem. Donec et arcu augue.</p>
          </div>
        </td>
      </tr>
    </tbody>
  </table>
  <table>
    <tbody>
      <tr>
        <td style="text-align: center">
          <div class="sub-container">
            <a class="button" style="font-size: 24px; margin: 1rem 0">Call to Action</a>
          </div>
        </td>
      </tr>
    </tbody>
  </table>