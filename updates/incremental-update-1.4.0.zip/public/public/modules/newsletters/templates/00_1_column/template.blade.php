<div style="background-color: #efefef">
  <div class="container" style="background-color: #fff">
    <table>
      <tbody>
        <tr>
          <td>
            <img src="{{ url('modules/newsletters/assets/img/logo.png') }}" style="margin:3rem auto"/>
          </td>
        </tr>
      </tbody>
    </table>
    <table>
      <tbody>
        <tr>
          <td>
            <h1 class="heading">Insert title here</h1>
            <p class="paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque enim ligula, interdum sed egestas id, viverra sit amet nisi. Morbi a hendrerit sem. Donec et arcu augue.</p>
          </td>
        </tr>
      </tbody>
    </table>
    <table>
      <tbody>
        <tr>
          <td>
            <img src="{{ url('modules/newsletters/assets/img/image.png') }}"/>
          </td>
        </tr>
      </tbody>
    </table>
    <table>
      <tbody>
        <tr>
          <td>
            <h1 class="heading">Insert title here</h1>
            <p class="paragraph">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque enim ligula, interdum sed egestas id, viverra sit amet nisi. Morbi a hendrerit sem. Donec et arcu augue.</p>
          </td>
        </tr>
      </tbody>
    </table>
    <table>
      <tbody>
        <tr>
          <td style="text-align: center">
            <a class="button" style="font-size: 24px; margin: 1rem 0">Call to Action</a>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</div>